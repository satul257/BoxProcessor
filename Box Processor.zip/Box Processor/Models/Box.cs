﻿namespace Box_Processor.Models
{
    /// <summary>
    /// Represents a box entity.
    /// </summary>
    public class Box
    {
        /// <summary>
        /// Gets or sets the supplier identifier.
        /// </summary>
        public string SupplierIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the box identifier.
        /// </summary>
        public string BoxIdentifier { get; set; }

        private List<Content> _contents = new List<Content>();
        /// <summary>
        /// Gets the contents of the box.
        /// </summary>
        public IReadOnlyCollection<Content> Contents => _contents;

        /// <summary>
        /// Adds a content to the box.
        /// </summary>
        /// <param name="content">The content to add.</param>
        public void AddContent(Content content)
        {
            if (content == null)
            {
                throw new ArgumentNullException(nameof(content), "Content cannot be null.");
            }
           
            _contents.Add(content);
        }

        /// <summary>
        /// Represents the content of a box.
        /// </summary>
        public class Content
        {            
            public string? PoNumber { get; set; }
           
            public string? ProductBarcode { get; set; }
           
            public int? Quantity { get; set; }
        }
    }
}
