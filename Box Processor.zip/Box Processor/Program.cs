﻿using Box_Processor.Interfaces;
using Box_Processor;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

public class Program
{
    static void Main(string[] args)
    {
        var serviceProvider = Startup.ConfigureServices();

        // Retrieve the file path from app settings
        var configuration = serviceProvider.GetRequiredService<IConfiguration>();
        var filePath = configuration["InputFilePath"];

        // Resolve FileTrackingService instance
        var fileTrackingService = serviceProvider.GetService<IFileTrackingService>();

        // Start monitoring
        fileTrackingService?.StartMonitoring();

        Console.WriteLine($"Monitoring directory: {Path.GetDirectoryName(filePath)}");
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}