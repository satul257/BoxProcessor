﻿using Box_Processor.Models;

namespace Box_Processor.Interfaces
{
    /// <summary>
    /// Interface for saving boxes to a repository.
    /// </summary>
    public interface IBoxRepository
    {
        /// <summary>
        /// Saves a collection of boxes to the repository.
        /// </summary>
        /// <param name="boxes">The collection of boxes to save.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task SaveBoxes(IEnumerable<Box> boxes);
    }

}
