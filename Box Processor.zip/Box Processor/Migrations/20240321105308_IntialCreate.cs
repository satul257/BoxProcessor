﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Box_Processor.Migrations
{
    public partial class IntialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Boxes",
                columns: table => new
                {
                    BoxIdentifier = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    SupplierIdentifier = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Boxes", x => x.BoxIdentifier);
                });

            migrationBuilder.CreateTable(
                name: "Content",
                columns: table => new
                {
                    ProductBarcode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PoNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: true),
                    BoxIdentifier = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Content", x => x.ProductBarcode);
                    table.ForeignKey(
                        name: "FK_Content_Boxes_BoxIdentifier",
                        column: x => x.BoxIdentifier,
                        principalTable: "Boxes",
                        principalColumn: "BoxIdentifier");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Content_BoxIdentifier",
                table: "Content",
                column: "BoxIdentifier");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Content");

            migrationBuilder.DropTable(
                name: "Boxes");
        }
    }
}
