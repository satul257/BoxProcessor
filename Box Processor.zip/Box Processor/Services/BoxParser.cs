﻿using Box_Processor.Interfaces;
using Box_Processor.Models;

namespace Box_Processor.Services
{
    /// <summary>
    /// Implementation of the <see cref="IBoxParser"/> interface for parsing box-related data from a file.
    /// </summary>
    public class BoxParser : IBoxParser
    {
        /// <summary>
        /// Parses the file located at the specified <paramref name="filePath"/> and extracts box-related data.
        /// </summary>
        /// <param name="filePath">The path to the file to be parsed.</param>
        /// <returns>A collection of <see cref="Box"/> objects containing the parsed data.</returns>
        public async Task<IEnumerable<Box>> ProcessFile(string filePath)
        {
            using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var streamReader = new StreamReader(fileStream))
            {
                string line;               
                var boxes = new List<Box>();

                while ((line = await streamReader.ReadLineAsync()) != null)
                {
                    if (line.StartsWith("HDR"))
                    {
                        var currentBox = new Box(); // Create a new Box object for each new box encountered
                        ParseHeaderLine(line, currentBox);
                        boxes.Add(currentBox); // Add the current box to the list

                    }
                    else if (line.StartsWith("LINE"))
                    {
                        // Ensure that there is a current box before parsing content line
                        if (boxes.Count > 0)
                        {
                            ParseContentLine(line, boxes[boxes.Count - 1]); // Parse content line for the last added box
                        }
                        else
                        {
                            Console.WriteLine("Warning...........There is no box to add.......");
                        }
                    }
                }              

                //  await SaveBoxesToDatabase(boxes);
                Console.WriteLine($"Succefully Parsed file: {filePath}");
                return boxes;
            }
        }

        /// <summary>
        /// Parses the header line of the file and updates the properties of the <paramref name="currentBox"/>.
        /// </summary>
        /// <param name="line">The header line to be parsed.</param>
        /// <param name="currentBox">The current <see cref="Box"/> object being processed.</param>

        private void ParseHeaderLine(string line, Box currentBox)
        {
            if (TryParseHeader(line, out string supplierIdentifier, out string boxIdentifier))
            {
                currentBox.SupplierIdentifier = supplierIdentifier;
                currentBox.BoxIdentifier = boxIdentifier;
            }
        }

        private bool TryParseHeader(string line, out string supplierIdentifier, out string boxIdentifier)
        {
            supplierIdentifier = null;
            boxIdentifier = null;

            if (string.IsNullOrWhiteSpace(line))
            {
                HandleError("Input line is null or empty.");
                return false;
            }

            string[] parts = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 3)
            {
                HandleError($"Insufficient parts in line '{line}'.");
                return false;
            }

            supplierIdentifier = parts[1].Trim();
            boxIdentifier = parts[2].Trim();

            return true;
        }

        /// <summary>
        /// Parses a content line of the file and adds a new <see cref="Box.Content"/> object to the <paramref name="currentBox"/>.
        /// </summary>
        /// <param name="line">The content line to be parsed.</param>
        /// <param name="currentBox">The current <see cref="Box"/> object being processed.</param>

        private void ParseContentLine(string line, Box currentBox)
        {
            if (TryParseContent(line, out var content))
            {
                // Add content to the current box
                currentBox.AddContent(content);
            }
        }

        private bool TryParseContent(string line, out Box.Content content)
        {
            content = null;

            if (string.IsNullOrWhiteSpace(line))
            {
                HandleError("Input line is null or empty.");
                return false;
            }

            string[] parts = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 4)
            {
                HandleError($"Insufficient parts in line '{line}'.");
                return false;
            }

            string poNumber = parts[1];
            string productBarcode = parts[2];
            if (!int.TryParse(parts[3], out int quantity))
            {
                HandleError($"Invalid quantity format in line '{line}'.");
                return false;
            }

            content = new Box.Content
            {
                PoNumber = poNumber,
                ProductBarcode = productBarcode,
                Quantity = quantity
            };

            return true;
        }

        private void HandleError(string errorMessage)
        {
            // Handle error (e.g., log, display to user, etc.)
            Console.WriteLine($"Error: {errorMessage}");
        }
    }
}
