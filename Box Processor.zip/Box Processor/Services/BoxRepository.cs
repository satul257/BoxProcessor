﻿using Box_Processor.DBContext;
using Box_Processor.Interfaces;
using Box_Processor.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Box_Processor.Services
{
    /// <summary>
    /// Implementation of the <see cref="IBoxRepository"/> interface.
    /// </summary>
    public class BoxRepository : IBoxRepository
    {
        private readonly AppDbContext _dbContext;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="BoxRepository"/> class.
        /// </summary>
        /// <param name="dbContext">The database context.</param>
        /// <param name="configuration">The configuration.</param>

        public BoxRepository(AppDbContext dbContext, IConfiguration configuration)
        {
            _dbContext = dbContext;
            _configuration = configuration;
        }

        /// <summary>
        /// Saves the provided boxes to the database.
        /// </summary>
        /// <param name="boxes">The boxes to save.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task SaveBoxes(IEnumerable<Box> boxes)
        {
            // Adjust batch size as needed
            var batchSize = Convert.ToInt32(_configuration["BatchSize"]);

            Console.WriteLine($"Batch Size to process is {batchSize}");
            // Retrieve existing box identifiers from the database
            var existingBoxIds = await _dbContext.Boxes.Select(b => b.BoxIdentifier).ToListAsync();

            // Create a list to store boxes to be saved
            var boxesToSave = boxes.Where(box => !existingBoxIds.Contains(box.BoxIdentifier)).ToList();

            // Iterate over boxes to be saved and save them in batches
            for (int i = 0; i < boxesToSave.Count; i += batchSize)
            {
                var currentBatch = boxesToSave.Skip(i).Take(batchSize).ToList();
                _dbContext.Boxes.AddRange(currentBatch);
                await _dbContext.SaveChangesAsync();

                // Detach entities after saving
                foreach (var box in currentBatch)
                {
                    _dbContext.Entry(box).State = EntityState.Detached;
                }

                Console.WriteLine($"Successfully saved {currentBatch.Count} box/boxes record(s) to Database");
            }
            Console.WriteLine($"Processed  {boxesToSave.Count} box/boxes record(s)");
        }
    }
}
