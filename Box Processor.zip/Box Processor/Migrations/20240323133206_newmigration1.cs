﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Box_Processor.Migrations
{
    public partial class newmigration1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
