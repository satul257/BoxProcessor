﻿using Box_Processor.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace Box_Processor
{
    /// <summary>
    /// FileTrackingService class responsible for monitoring a directory for new files,
    /// processing them asynchronously, and handling file locking issues.
    /// </summary>
    public class FileTrackingService : IFileTrackingService
    {
        // Fields
        private readonly string _monitoringPath;
        private IBoxParser _parser;
        private IBoxRepository _boxRepository;
        private const int MAX_RETRY = 3;
        private int delayMS = 1000; // Initial delay
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="FileTrackingService"/> class.
        /// </summary>
        /// <param name="monitoringPath">The path of the directory to monitor.</param>
        /// <param name="boxParser">The box parser service.</param>
        /// <param name="boxRepository">The box repository service.</param>
        /// <param name="configuration">The configuration.</param>
        public FileTrackingService(string monitoringPath, IBoxParser boxParser, IBoxRepository boxRepository, IConfiguration configuration)
        {
            _monitoringPath = monitoringPath;
            _parser = boxParser;
            _boxRepository = boxRepository;
            _configuration = configuration;
        }


        /// <summary>
        /// Starts monitoring the specified directory for new files.
        /// When a new file is created, it processes it with retry logic.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task StartMonitoring()
        {
            using (var fileWatcher = new FileSystemWatcher(_monitoringPath))
            {
                fileWatcher.Created += async (sender, e) =>
                {
                    string filePath = e.FullPath;
                    await WaitForFile(filePath); // Wait for the file to become available
                    await ProcessFileWithRetry(filePath); // Process the file with retry logic
                };

                fileWatcher.EnableRaisingEvents = true;

                Console.WriteLine($"Monitoring {_monitoringPath} for new files...");
                Console.ReadLine(); // Keep the application running
            }
        }

        /// <summary>
        /// Waits for a specified file to become available by checking for file locking.
        /// Throws an exception if the file is still locked after the maximum number of attempts.
        /// </summary>
        /// <param name="filePath">The path of the file to wait for.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task WaitForFile(string filePath)
        {
            int attempts = 0;
            int maxAttempts = Convert.ToInt32(_configuration["MaxAttempt"]);// 3;
            int delayBetweenAttemptsMs = Convert.ToInt32(_configuration["DelayBetweenAttempt"]); // 1 second delay

            while (IsFileLocked(filePath) && attempts < maxAttempts)
            {
                attempts++;
                await Task.Delay(delayBetweenAttemptsMs);
            }

            if (IsFileLocked(filePath))
            {
                throw new Exception($"File '{filePath}' is still in use after {maxAttempts} attempts.");
            }
        }

        /// <summary>
        /// Processes the specified file with retry logic in case of failures.
        /// </summary>
        /// <param name="filePath">The path to the file.</param>
        public async Task ProcessFileWithRetry(string filePath)
        {
            delayMS = Convert.ToInt32(_configuration["DelayWhileRetryProcessingFile"]);
            for (int attempt = 1; attempt <= MAX_RETRY; attempt++)
            {
                try
                {
                    var box = await _parser.ProcessFile(filePath);
                    await _boxRepository.SaveBoxes(box);

                    // If the operation succeeded, break out of the retry loop
                    break;
                }
                catch (InvalidOperationException ex)
                {
                    // Check if the exception message indicates the duplicate tracking error
                    if (ex.Message.Contains("instance with the key value"))
                    {                        
                        Console.WriteLine("Error: Duplicate tracking detected. Please check your data operations.");
                     
                    }
                    else
                    {                        
                        Console.WriteLine("An error occurred: " + ex.Message);                       
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing file '{_monitoringPath}': {ex.Message}");

                    // If it's the last attempt break
                    if (attempt == MAX_RETRY)
                        break;

                    
                    await Task.Delay(delayMS);
                }
            }
        }

        /// <summary>
        /// Checks if the specified file is locked (being used by another process).
        /// </summary>
        /// <param name="filePath">The path to the file.</param>
        /// <returns>True if the file is locked; otherwise, false.</returns>
        private bool IsFileLocked(string filePath)
        {
            try
            {
                using (FileStream fs = File.Open(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {
                    return false;
                }
            }
            catch (IOException)
            {
                return true;
            }
        }
    }
}
