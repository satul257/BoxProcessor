﻿namespace Box_Processor.Interfaces
{
    public interface IFileTrackingService
    {
        public  Task StartMonitoring();
        public Task ProcessFileWithRetry(string filePath);

    }
}
