﻿using Box_Processor.Models;

namespace Box_Processor.Interfaces
{
    /// <summary>
    /// Interface for parsing files and extracting boxes.
    /// </summary>
    public interface IBoxParser
    {
        /// <summary>
        /// Processes the specified file and extracts boxes.
        /// </summary>
        /// <param name="filePath">The path of the file to process.</param>
        /// <returns>An enumerable collection of boxes extracted from the file.</returns>
        Task<IEnumerable<Box>> ProcessFile(string filePath);
    }

}
