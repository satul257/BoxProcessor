﻿using Box_Processor.DBContext;
using Box_Processor.Interfaces;
using Box_Processor.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Box_Processor
{
    /// <summary>
    /// Configures and registers services and dependencies for the application.
    /// </summary>
    /// <returns>The configured <see cref="IServiceProvider"/> instance.</returns>
    public class Startup
    {
        public static IServiceProvider ConfigureServices()
        {
            var services = new ServiceCollection();

            // Registering dependencies here
            services.AddTransient<IBoxParser, BoxParser>();
            services.AddTransient<IBoxRepository, BoxRepository>();

            var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();
            services.AddSingleton<IConfiguration>(configuration);

            // Retrieve the connection string from configuration
            var connectionString = configuration.GetConnectionString("DefaultConnection");         

            
            // Add DbContext using the retrieved connection string
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(connectionString));


            // Configure monitoringPath 
            var monitoringPath = configuration["InputFilePath"];
            services.AddTransient<IFileTrackingService>(provider =>
            {
                var parser= provider.GetService<IBoxParser>();
                var boxRepository= provider.GetService<IBoxRepository>();
                return new FileTrackingService(monitoringPath, parser,boxRepository,configuration);
            });

        

            return services.BuildServiceProvider();
        }
    }
}
