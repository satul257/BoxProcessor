﻿using Box_Processor.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using static Box_Processor.Models.Box;

namespace Box_Processor.DBContext
{
    /// <summary>
    /// Represents the application's database context.
    /// </summary>
    public class AppDbContext: DbContext
    {
        private  string _connectionString; 

        public DbSet<Box> Boxes { get; set; }

        public AppDbContext() // to run migration necessary to put empty constructur
        {

        }
        /// <summary>
        /// Initializes a new instance of the <see cref="AppDbContext"/> class.
        /// </summary>
        /// <param name="configuration">The application configuration.</param>
        public AppDbContext(IConfiguration configuration) => _connectionString = configuration.GetConnectionString("DefaultConnection");

        /// <summary>
        /// Configures the database connection.
        /// </summary>
        /// <param name="optionsBuilder">The options builder for configuring the context.</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfiguration configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json")
                    .Build();

                _connectionString = configuration.GetConnectionString("DefaultConnection");
                optionsBuilder.UseSqlServer(_connectionString);
                optionsBuilder.EnableSensitiveDataLogging(); // neded for troublehsooting
            }
        }

        /// <summary>
        /// Configures the entity models.
        /// </summary>
        /// <param name="modelBuilder">The model builder for configuring entities.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Box>()
                .HasKey(e => e.BoxIdentifier);

            modelBuilder.Entity<Content>()
                .HasKey(c => new { c.ProductBarcode, c.PoNumber }); // composit Key
        }

    }
}
